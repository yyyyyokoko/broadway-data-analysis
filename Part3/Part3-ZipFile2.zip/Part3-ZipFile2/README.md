Website Link: https://sites.google.com/view/501finalprojectwebsite/home

In the folder "Website", each folder represents a main tab on the website. In each folder, the file ending in .html is the local copy of that page on the website. 